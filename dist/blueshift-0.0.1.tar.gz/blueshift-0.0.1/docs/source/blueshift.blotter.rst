blueshift.blotter package
=========================

Submodules
----------

blueshift.blotter.blotter module
--------------------------------

.. automodule:: blueshift.blotter.blotter
    :members:
    :undoc-members:
    :show-inheritance:

blueshift.blotter.events module
-------------------------------

.. automodule:: blueshift.blotter.events
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: blueshift.blotter
    :members:
    :undoc-members:
    :show-inheritance:
