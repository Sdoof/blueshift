.. Blueshift documentation master file, created by
   sphinx-quickstart on Thu Jan 31 17:49:03 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
.. note:: for internal use only

Welcome to Blueshift's documentation!
=====================================
Some text here

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   concepts
   api
   modules

    

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
