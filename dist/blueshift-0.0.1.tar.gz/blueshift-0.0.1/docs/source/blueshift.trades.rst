blueshift.trades package
========================

Module contents
---------------

.. automodule:: blueshift.trades
    :members:
    :undoc-members:
    :show-inheritance:
