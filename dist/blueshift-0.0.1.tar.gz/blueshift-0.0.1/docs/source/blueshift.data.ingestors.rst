blueshift.data.ingestors package
================================

Submodules
----------

blueshift.data.ingestors.ingestor module
----------------------------------------

.. automodule:: blueshift.data.ingestors.ingestor
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: blueshift.data.ingestors
    :members:
    :undoc-members:
    :show-inheritance:
