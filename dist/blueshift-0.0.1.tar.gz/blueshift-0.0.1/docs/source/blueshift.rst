.. note:: for internal use only

blueshift package
=================

Subpackages
-----------

.. toctree::

    blueshift.alerts
    blueshift.algorithm
    blueshift.assets
    blueshift.blotter
    blueshift.brokers
    blueshift.configs
    blueshift.data
    blueshift.execution
    blueshift.trades
    blueshift.utils

Submodules
----------

blueshift.api module
--------------------

.. automodule:: blueshift.api
    :members:
    :undoc-members:
    :show-inheritance:
    :ignore-module-all:


Module contents
---------------

.. automodule:: blueshift
    :members:
    :undoc-members:
    :show-inheritance:
    :ignore-module-all:
