blueshift.assets package
========================

Submodules
----------

blueshift.assets.assets module
------------------------------

.. automodule:: blueshift.assets.assets
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: blueshift.assets
    :members:
    :undoc-members:
    :show-inheritance:
