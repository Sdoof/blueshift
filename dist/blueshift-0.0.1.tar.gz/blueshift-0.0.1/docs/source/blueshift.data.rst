blueshift.data package
======================

Subpackages
-----------

.. toctree::

    blueshift.data.ingestors
    blueshift.data.interfaces

Submodules
----------

blueshift.data.dataportal module
--------------------------------

.. automodule:: blueshift.data.dataportal
    :members:
    :undoc-members:
    :show-inheritance:
    :ignore-module-all:
    :noindex:

blueshift.data.rest\_data module
--------------------------------

.. automodule:: blueshift.data.rest_data
    :members:
    :undoc-members:
    :show-inheritance:
    :ignore-module-all:


Module contents
---------------

.. automodule:: blueshift.data
    :members:
    :undoc-members:
    :show-inheritance:
