blueshift.brokers package
===============================

Subpackages
-----------

.. toctree::

    blueshift.brokers.backtest
    blueshift.brokers.fxcm
    blueshift.brokers.zerodha

Submodules
----------

blueshift.brokers.core module
-----------------------------------

.. automodule:: blueshift.brokers.core
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: blueshift.brokers
    :members:
    :undoc-members:
    :show-inheritance:
